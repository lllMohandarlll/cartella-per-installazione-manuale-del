package thKaguyaMod.entity.spellcard;

public class THSC_Spear_the_Gungnir extends THSpellCard
{
	//神槍「スピア・ザ・グングニル」
	
	public THSC_Spear_the_Gungnir()
	{
		this.setNeedLevel(3);
		this.setRemoveTime(10);
		this.setEndTime(50);
		this.setOriginalUserName(REMILIA);
	}
}
