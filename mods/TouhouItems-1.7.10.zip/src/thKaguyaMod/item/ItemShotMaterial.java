package thKaguyaMod.item;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemShotMaterial extends Item
{
	
	//弾幕の素　弾幕を作成する為の素材
	
	public ItemShotMaterial()
	{
		super();
		this.setTextureName("thkaguyamod:material/ShotMaterial");//テクスチャの指定
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
	}
	
}