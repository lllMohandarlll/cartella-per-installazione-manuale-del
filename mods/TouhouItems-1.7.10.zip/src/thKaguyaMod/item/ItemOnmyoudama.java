package thKaguyaMod.item;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemOnmyoudama extends Item
{
       
	//陰陽玉
	
	public ItemOnmyoudama()
	{
		super();
		this.setTextureName("thkaguyamod:material/Onmyoudama");//テクスチャの指定
		setCreativeTab(CreativeTabs.tabMaterials);//クリエイティブの素材タブに登録
		this.maxStackSize = 1;//最大スタック数
	}
}
