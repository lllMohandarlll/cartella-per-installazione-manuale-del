package thKaguyaMod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import cpw.mods.fml.common.network.IGuiHandler;

public class GuiHandler implements IGuiHandler
{
	
	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
	{
		if (ID == THKaguyaCore.guiDanmakuCraftingID )
		{
			return new GuiDanmakuCrafting(player, world, x, y, z);
		}
		else if(ID == THKaguyaCore.guiDanmakuCraftingLaserID)
		{
			return new GuiDanmakuCraftingLaser(player, world, x, y, z);
		}
		else if(ID == THKaguyaCore.guiMerchantSanaeId)
		{
			return new GuiMerchantSanae(player, world, "Sanae");
		}
 
		return null;
	}
 
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
	{
		if (ID == THKaguyaCore.guiDanmakuCraftingID )
		{
			return new ContainerDanmakuCrafting(player.inventory, world, x, y, z);
		}
		else if(ID == THKaguyaCore.guiDanmakuCraftingLaserID)
		{
			return new ContainerDanmakuCraftingLaser(player.inventory, world, x, y, z);
		}
		else if(ID == THKaguyaCore.guiMerchantSanaeId)
		{
			return new ContainerMerchantSanae(player, world);
		}
 
		return null;
	}
}
